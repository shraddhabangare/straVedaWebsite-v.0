import Hero from '@/components/sections/Hero';
import ServicesGrid from '@/components/sections/ServicesGrid';
import AboutStats from '@/components/sections/AboutStats';
import Testimonials from '@/components/sections/Testimonials';
import ContactCTA from '@/components/sections/ContactCTA';
import Divider from '@/components/ui/Divider';

export const revalidate = 86400;

export default function HomePage() {
  return (
    <main className="flex flex-col min-h-screen pt-16">
      <Hero />
      <Divider />
      <ServicesGrid />
      <Divider />
      <AboutStats />
      <Divider />
      <Testimonials />
      <ContactCTA />
    </main>
  );
}
