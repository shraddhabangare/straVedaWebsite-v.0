import Link from 'next/link';
import { ArrowRight, Calendar } from 'lucide-react';
import Newsletter from '@/components/sections/Newsletter';
import Divider from '@/components/ui/Divider';
import SectionLabel from '@/components/ui/SectionLabel';
import { getPosts } from '@/lib/insights';
import { FadeUpStagger, FadeUpItem } from '@/components/ui/MotionWrapper';

export const revalidate = 3600;

export const metadata = {
  title: "Enterprise IT Insights & Perspectives | Straveda Blog",
  description: "Enterprise architecture, technology strategy, and management insights from the Straveda team. Practical guidance for modern organizations.",
  alternates: { canonical: 'https://straveda.com/insights' },
};

export default function InsightsPage() {
  const posts = getPosts();

  return (
    <main className="flex flex-col min-h-screen pt-16">
      {/* Hero */}
      <section className="min-h-[50vh] flex items-center justify-center px-10 py-24 bg-zinc-50">
        <FadeUpStagger className="max-w-container mx-auto w-full text-center">
          <FadeUpItem>
            <SectionLabel className="mx-auto">Insights & Perspectives</SectionLabel>
          </FadeUpItem>
          <FadeUpItem>
            <h1 className="text-hero font-semibold mb-8 text-black tracking-tight">
              Thinking <span className="text-brand-orange">forward.</span>
            </h1>
          </FadeUpItem>
          <FadeUpItem>
            <p className="text-lg text-zinc-600 max-w-2xl mx-auto">
              Expert analysis, strategic guidance, and practical advice from our team of enterprise IT consultants.
            </p>
          </FadeUpItem>
        </FadeUpStagger>
      </section>

      <Divider />

      {/* Featured Post */}
      <section className="py-section px-10 max-w-container mx-auto w-full">
        <Link href={`/insights/${posts[0].slug}`}>
          <div className="bg-white rounded-2xl border border-zinc-200 overflow-hidden flex flex-col md:flex-row group cursor-pointer hover:border-brand-orange/50 transition-colors shadow-sm hover:shadow-md">
            <div className="md:w-1/2 bg-zinc-50 p-12 flex flex-col justify-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-brand-orange/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <span className="text-xs font-medium uppercase tracking-[0.14em] text-brand-orange mb-4 relative z-10">Featured Article</span>
              <h2 className="text-3xl md:text-4xl font-medium leading-[1.2] mb-6 relative z-10 text-black group-hover:text-brand-orange transition-colors">
                {posts[0].title}
              </h2>
              <p className="text-zinc-600 leading-[1.6] mb-8 relative z-10">
                {posts[0].excerpt}
              </p>
              <div className="flex items-center gap-4 text-sm text-zinc-500 relative z-10">
                <span className="flex items-center gap-1.5"><Calendar size={14} /> {posts[0].date}</span>
                <span>•</span>
                <span>{posts[0].readTime}</span>
              </div>
            </div>
            <div className="md:w-1/2 bg-zinc-200 min-h-[300px] relative">
              {/* Placeholder for featured image */}
              <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/enterprise/800/600')] bg-cover bg-center opacity-60 mix-blend-luminosity group-hover:opacity-80 transition-opacity duration-500" />
            </div>
          </div>
        </Link>
      </section>

      {/* Post Grid */}
      <section className="pb-section px-10 max-w-container mx-auto w-full">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.slice(1).map((post) => (
            <Link key={post.id} href={`/insights/${post.slug}`}>
              <article className="bg-white rounded-xl p-8 border border-zinc-200 flex flex-col h-full hover:-translate-y-1.5 hover:shadow-[0_24px_48px_rgba(0,0,0,0.08)] transition-all duration-300 group cursor-pointer">
                <div className="mb-6">
                  <span className="inline-block px-3 py-1 rounded-full bg-brand-orange/10 text-brand-orange text-xs font-medium mb-4">
                    {post.category}
                  </span>
                  <h3 className="text-[22px] font-medium leading-[1.3] mb-3 text-black group-hover:text-brand-orange transition-colors">{post.title}</h3>
                  <p className="text-zinc-600 text-[15px] leading-[1.6]">{post.excerpt}</p>
                </div>
                <div className="mt-auto pt-6 border-t border-zinc-200 flex items-center justify-between text-sm text-zinc-500">
                  <span>{post.date}</span>
                  <span className="flex items-center gap-1 group-hover:text-brand-orange transition-colors">
                    Read <ArrowRight size={14} />
                  </span>
                </div>
              </article>
            </Link>
          ))}
        </div>
      </section>

      <Newsletter />
    </main>
  );
}
