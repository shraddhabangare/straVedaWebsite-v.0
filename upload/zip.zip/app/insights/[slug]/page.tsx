import { getPosts, getPostBySlug } from '@/lib/insights';
import { notFound } from 'next/navigation';
import Newsletter from '@/components/sections/Newsletter';
import { Calendar, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { FadeUpStagger, FadeUpItem } from '@/components/ui/MotionWrapper';

export const revalidate = 3600;

export async function generateStaticParams() {
  const posts = getPosts();
  return posts.map((post) => ({
    slug: post.slug,
  }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = getPostBySlug(slug);
  
  if (!post) {
    return { title: 'Post Not Found' };
  }

  return {
    title: `${post.title} | Straveda Insights`,
    description: post.excerpt,
    alternates: { canonical: `https://straveda.com/insights/${slug}` },
  };
}

export default async function PostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = getPostBySlug(slug);

  if (!post) {
    notFound();
  }

  return (
    <main className="flex flex-col min-h-screen pt-16">
      <article className="max-w-3xl mx-auto px-10 py-24 w-full">
        <Link href="/insights" className="inline-flex items-center gap-2 text-sm text-zinc-500 hover:text-brand-orange transition-colors mb-12">
          <ArrowLeft size={16} /> Back to Insights
        </Link>
        
        <FadeUpStagger className="mb-12">
          <FadeUpItem>
            <span className="inline-block px-3 py-1 rounded-full bg-brand-orange/10 text-brand-orange text-xs font-medium mb-6">
              {post.category}
            </span>
          </FadeUpItem>
          <FadeUpItem>
            <h1 className="text-4xl md:text-5xl font-semibold leading-[1.1] mb-6 text-black tracking-tight">
              {post.title}
            </h1>
          </FadeUpItem>
          <FadeUpItem>
            <div className="flex items-center gap-4 text-sm text-zinc-500">
              <span className="flex items-center gap-1.5"><Calendar size={14} /> {post.date}</span>
              <span>•</span>
              <span>{post.readTime}</span>
            </div>
          </FadeUpItem>
        </FadeUpStagger>

        <div className="prose prose-zinc prose-orange max-w-none">
          <p className="text-xl text-zinc-700 leading-relaxed mb-8">
            {post.excerpt}
          </p>
          <p className="text-zinc-600 leading-relaxed mb-6">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
          </p>
          <h2 className="text-2xl font-medium text-black mt-12 mb-6">The Strategic Imperative</h2>
          <p className="text-zinc-600 leading-relaxed mb-6">
            Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
          </p>
          <ul className="list-disc pl-6 text-zinc-600 mb-6 space-y-2">
            <li>Aligning technology with business objectives</li>
            <li>Reducing technical debt and complexity</li>
            <li>Improving time-to-market for new features</li>
          </ul>
          <p className="text-zinc-600 leading-relaxed">
            Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.
          </p>
        </div>
      </article>

      <Newsletter />
    </main>
  );
}
