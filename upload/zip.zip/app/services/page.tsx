import { Building2, Lightbulb, LineChart, Server, CheckCircle2, Shield, Zap, Target } from 'lucide-react';
import ContactCTA from '@/components/sections/ContactCTA';
import Divider from '@/components/ui/Divider';
import SectionLabel from '@/components/ui/SectionLabel';
import Card from '@/components/ui/Card';
import { FadeUpStagger, FadeUpItem } from '@/components/ui/MotionWrapper';

export const revalidate = 86400;

export const metadata = {
  title: "Enterprise IT Services — Architecture, Strategy & Management | Straveda",
  description: "Explore Straveda's enterprise services: architecture modernization, technology strategy, management consulting, and Red Hat software solutions. Plano, TX.",
  alternates: { canonical: 'https://straveda.com/services' },
};

export default function ServicesPage() {
  return (
    <main className="flex flex-col min-h-screen pt-16">
      {/* Hero */}
      <section className="min-h-[60vh] flex items-center justify-center px-10 py-24 bg-zinc-50">
        <FadeUpStagger className="max-w-container mx-auto w-full text-center">
          <FadeUpItem>
            <SectionLabel className="mx-auto">What We Do</SectionLabel>
          </FadeUpItem>
          <FadeUpItem>
            <h1 className="text-hero font-semibold mb-8 text-black tracking-tight">
              Enterprise <span className="text-brand-orange">Capabilities.</span>
            </h1>
          </FadeUpItem>
          <FadeUpItem>
            <p className="text-lg text-zinc-600 max-w-2xl mx-auto">
              Comprehensive IT consulting services designed to modernize your architecture, align technology with business goals, and deliver complex programs successfully.
            </p>
          </FadeUpItem>
        </FadeUpStagger>
      </section>

      <Divider />

      {/* Service Blocks */}
      <section className="py-section px-10 max-w-container mx-auto w-full flex flex-col gap-24">
        {/* Service 1 */}
        <div id="architecture" className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="order-2 lg:order-1">
            <div className="w-16 h-16 rounded-xl bg-brand-orange/10 flex items-center justify-center mb-8">
              <Building2 size={32} className="text-brand-orange" />
            </div>
            <h2 className="text-3xl md:text-4xl font-medium mb-6 text-black">Enterprise Architecture</h2>
            <p className="text-lg text-zinc-600 leading-[1.65] mb-8">
              We help organizations design and implement robust, scalable, and adaptive architectures. By leveraging open standards and modern design patterns, we ensure your IT infrastructure can support future growth and innovation.
            </p>
            <ul className="flex flex-col gap-4">
              {['Microservices & API Strategy', 'Cloud-Native Architecture', 'Legacy System Modernization', 'Architecture Governance'].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-zinc-700">
                  <CheckCircle2 size={20} className="text-brand-orange shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="order-1 lg:order-2 bg-zinc-100 rounded-2xl aspect-square lg:aspect-auto lg:h-full min-h-[400px] relative overflow-hidden border border-zinc-200">
            <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/architecture/800/800')] bg-cover bg-center opacity-40 mix-blend-luminosity" />
          </div>
        </div>

        {/* Service 2 */}
        <div id="strategy" className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="bg-zinc-100 rounded-2xl aspect-square lg:aspect-auto lg:h-full min-h-[400px] relative overflow-hidden border border-zinc-200">
            <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/strategy/800/800')] bg-cover bg-center opacity-40 mix-blend-luminosity" />
          </div>
          <div>
            <div className="w-16 h-16 rounded-xl bg-brand-orange/10 flex items-center justify-center mb-8">
              <Lightbulb size={32} className="text-brand-orange" />
            </div>
            <h2 className="text-3xl md:text-4xl font-medium mb-6 text-black">Technology Strategy</h2>
            <p className="text-lg text-zinc-600 leading-[1.65] mb-8">
              Aligning IT investments with business objectives is critical. We develop comprehensive technology roadmaps that prioritize initiatives, optimize resource allocation, and accelerate time-to-market.
            </p>
            <ul className="flex flex-col gap-4">
              {['IT Portfolio Assessment', 'Digital Transformation Roadmaps', 'Vendor Selection & Management', 'Technology Investment Planning'].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-zinc-700">
                  <CheckCircle2 size={20} className="text-brand-orange shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Service 3 */}
        <div id="consulting" className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="order-2 lg:order-1">
            <div className="w-16 h-16 rounded-xl bg-brand-orange/10 flex items-center justify-center mb-8">
              <LineChart size={32} className="text-brand-orange" />
            </div>
            <h2 className="text-3xl md:text-4xl font-medium mb-6 text-black">Management Consulting</h2>
            <p className="text-lg text-zinc-600 leading-[1.65] mb-8">
              Execution is everything. Our expert program and project managers bring rigorous methodologies and leadership to ensure your most critical enterprise initiatives are delivered successfully.
            </p>
            <ul className="flex flex-col gap-4">
              {['Program & Project Management', 'Agile Transformation', 'Change Management', 'IT Operating Model Design'].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-zinc-700">
                  <CheckCircle2 size={20} className="text-brand-orange shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="order-1 lg:order-2 bg-zinc-100 rounded-2xl aspect-square lg:aspect-auto lg:h-full min-h-[400px] relative overflow-hidden border border-zinc-200">
            <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/management/800/800')] bg-cover bg-center opacity-40 mix-blend-luminosity" />
          </div>
        </div>

        {/* Service 4 */}
        <div id="software" className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="bg-zinc-100 rounded-2xl aspect-square lg:aspect-auto lg:h-full min-h-[400px] relative overflow-hidden border border-zinc-200">
            <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/software/800/800')] bg-cover bg-center opacity-40 mix-blend-luminosity" />
          </div>
          <div>
            <div className="w-16 h-16 rounded-xl bg-brand-orange/10 flex items-center justify-center mb-8">
              <Server size={32} className="text-brand-orange" />
            </div>
            <h2 className="text-3xl md:text-4xl font-medium mb-6 text-black">Software Solutions</h2>
            <p className="text-lg text-zinc-600 leading-[1.65] mb-8">
              We specialize in implementing and optimizing Red Hat Enterprise Middleware and virtualization solutions to lower your Total Cost of Ownership (TCO) while increasing performance.
            </p>
            <ul className="flex flex-col gap-4">
              {['Red Hat JBoss EAP', 'OpenShift Container Platform', 'Integration & API Management', 'Performance Tuning'].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-zinc-700">
                  <CheckCircle2 size={20} className="text-brand-orange shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* Why Straveda */}
      <section className="py-section px-10 w-full bg-zinc-50 border-y border-zinc-200">
        <div className="max-w-container mx-auto">
          <div className="text-center mb-16">
            <SectionLabel className="mx-auto">The Straveda Difference</SectionLabel>
            <h2 className="text-section font-medium text-black">Why Choose Us</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card>
              <Shield size={32} className="text-brand-orange mb-6" />
              <h3 className="text-[22px] font-medium mb-4 text-black">Exceptional Value</h3>
              <p className="text-zinc-600 leading-[1.6]">We deliver tier-one consulting expertise without the bloated overhead of traditional large-scale firms.</p>
            </Card>
            <Card>
              <Zap size={32} className="text-brand-orange mb-6" />
              <h3 className="text-[22px] font-medium mb-4 text-black">Cost-Effective</h3>
              <p className="text-zinc-600 leading-[1.6]">Our solutions are designed to optimize your IT spend, focusing on open-source technologies and efficient architectures.</p>
            </Card>
            <Card>
              <Target size={32} className="text-brand-orange mb-6" />
              <h3 className="text-[22px] font-medium mb-4 text-black">Guaranteed Satisfaction</h3>
              <p className="text-zinc-600 leading-[1.6]">We measure our success entirely by yours. We don&apos;t consider an engagement complete until you are fully satisfied.</p>
            </Card>
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  );
}
