import type { Metadata } from 'next';
import { Geist } from 'next/font/google';
import './globals.css';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import SmoothScroll from '@/components/layout/SmoothScroll';

const geist = Geist({
  subsets: ['latin'],
  variable: '--font-geist',
});

export const metadata: Metadata = {
  metadataBase: new URL('https://straveda.com'),
  title: {
    default: 'Straveda LLC — Enterprise IT Consulting & Technology Strategy | Plano, TX',
    template: '%s | Straveda LLC',
  },
  description:
    'Straveda LLC provides enterprise IT consulting, technology strategy, enterprise architecture, and management consulting services. Based in Plano, Texas since 2010.',
  keywords: [
    'enterprise IT consulting',
    'technology strategy',
    'enterprise architecture',
    'management consulting',
    'IT modernization',
    'Red Hat middleware',
    'digital transformation',
    'Plano Texas IT consulting',
  ],
  authors: [{ name: 'Straveda LLC' }],
  creator: 'Straveda LLC',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://straveda.com',
    siteName: 'Straveda LLC',
    title: 'Straveda LLC — Enterprise IT Consulting & Technology Strategy',
    description:
      'Enterprise architecture, technology strategy, and management consulting for forward-thinking organizations. Plano, TX since 2010.',
    images: [{ url: '/og-image.png', width: 1200, height: 630 }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Straveda LLC — Enterprise IT Consulting',
    description: 'Enterprise architecture, technology strategy & management consulting — Plano, TX',
    images: ['/og-image.png'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large' },
  },
  alternates: { canonical: 'https://straveda.com' },
};

const organizationSchema = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'Straveda LLC',
  url: 'https://straveda.com',
  logo: 'https://straveda.com/logo.svg',
  description: 'Enterprise IT Consulting, Technology Strategy, and Management Consulting.',
  foundingDate: '2010',
  address: {
    '@type': 'PostalAddress',
    addressLocality: 'Plano',
    addressRegion: 'TX',
    postalCode: '75024',
    addressCountry: 'US',
  },
  contactPoint: {
    '@type': 'ContactPoint',
    email: 'info@straveda.com',
    contactType: 'customer service',
  },
  sameAs: ['https://www.linkedin.com/company/straveda-llc'],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${geist.variable} font-geist`}>
      <body suppressHydrationWarning className="bg-white text-black antialiased">
        <SmoothScroll>
          <Navbar />
          {children}
          <Footer />
        </SmoothScroll>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }}
        />
      </body>
    </html>
  );
}
