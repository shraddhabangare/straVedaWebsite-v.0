import { Target, Users, Award } from 'lucide-react';
import ContactCTA from '@/components/sections/ContactCTA';
import Divider from '@/components/ui/Divider';
import SectionLabel from '@/components/ui/SectionLabel';
import Card from '@/components/ui/Card';
import { FadeUpStagger, FadeUpItem } from '@/components/ui/MotionWrapper';

export const revalidate = 86400;

export const metadata = {
  title: "About Straveda LLC — Enterprise IT Consulting Since 2010 | Plano, TX",
  description: "Learn about Straveda LLC, an enterprise IT consulting firm founded in 2010 in Plano, Texas. Our mission: exceptional value and guaranteed satisfaction.",
  alternates: { canonical: 'https://straveda.com/about' },
};

export default function AboutPage() {
  return (
    <main className="flex flex-col min-h-screen pt-16">
      {/* Hero */}
      <section className="min-h-[70vh] flex items-center justify-center px-10 py-24 bg-zinc-50">
        <FadeUpStagger className="max-w-container mx-auto w-full text-center">
          <FadeUpItem>
            <SectionLabel className="mx-auto">Our Story</SectionLabel>
          </FadeUpItem>
          <FadeUpItem>
            <h1 className="text-hero font-semibold mb-8 text-black tracking-tight">
              Built on <span className="text-brand-orange">expertise.</span><br />
              Driven by <span className="text-brand-orange">value.</span>
            </h1>
          </FadeUpItem>
          <FadeUpItem>
            <p className="text-lg text-zinc-600 max-w-2xl mx-auto">
              Straveda LLC is an Enterprise IT Consulting & Technology Strategy company based in Plano, Texas, dedicated to solving complex business challenges through technology.
            </p>
          </FadeUpItem>
        </FadeUpStagger>
      </section>

      <Divider />

      {/* Mission */}
      <section id="mission" className="py-section px-10 max-w-container mx-auto w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-display font-semibold text-zinc-100" style={{ WebkitTextStroke: '2px #E4E4E7', color: 'transparent' }}>
              2010
            </h2>
            <p className="text-2xl font-medium mt-4 text-black">The year our journey began.</p>
          </div>
          <div className="flex flex-col gap-6">
            <h3 className="text-3xl font-medium mb-2 text-black">Our Mission</h3>
            <p className="text-lg text-zinc-700 leading-[1.65]">
              Provide Exceptional Value. Deliver Cost-Effective Solutions. Guarantee Customer Satisfaction.
            </p>
            <p className="text-zinc-600 leading-[1.65]">
              We believe that enterprise IT shouldn&apos;t be a black box of endless expenses. Our goal is to demystify technology strategy, providing clear, actionable roadmaps that align perfectly with your business objectives. We bring decades of collective experience to every engagement.
            </p>
          </div>
        </div>
      </section>

      <Divider />

      {/* Values */}
      <section id="values" className="py-section px-10 max-w-container mx-auto w-full">
        <div className="text-center mb-16">
          <SectionLabel className="mx-auto">What Drives Us</SectionLabel>
          <h2 className="text-section font-medium text-black">Core Values</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card>
            <Target size={32} className="text-brand-orange mb-6" />
            <h3 className="text-[22px] font-medium mb-4 text-black">Precision</h3>
            <p className="text-zinc-600 leading-[1.6]">We don&apos;t believe in one-size-fits-all. Every architecture and strategy is precisely tailored to your unique enterprise context.</p>
          </Card>
          <Card>
            <Users size={32} className="text-brand-orange mb-6" />
            <h3 className="text-[22px] font-medium mb-4 text-black">Partnership</h3>
            <p className="text-zinc-600 leading-[1.6]">We integrate with your teams, transferring knowledge and building internal capabilities that outlast our engagement.</p>
          </Card>
          <Card>
            <Award size={32} className="text-brand-orange mb-6" />
            <h3 className="text-[22px] font-medium mb-4 text-black">Excellence</h3>
            <p className="text-zinc-600 leading-[1.6]">We hold ourselves to the highest standards of technical and professional excellence in everything we deliver.</p>
          </Card>
        </div>
      </section>

      {/* Stats Strip */}
      <section className="w-full bg-zinc-50 border-y border-zinc-200">
        <div className="max-w-container mx-auto px-10 py-16">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center divide-x divide-zinc-200">
            <div className="flex flex-col items-center">
              <span className="text-4xl md:text-5xl font-semibold text-brand-orange mb-2">14+</span>
              <span className="text-sm text-zinc-500 uppercase tracking-wider">Years Experience</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-4xl md:text-5xl font-semibold text-brand-orange mb-2">7</span>
              <span className="text-sm text-zinc-500 uppercase tracking-wider">Expert Consultants</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-4xl md:text-5xl font-semibold text-brand-orange mb-2">100%</span>
              <span className="text-sm text-zinc-500 uppercase tracking-wider">Client Satisfaction</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-4xl md:text-5xl font-semibold text-brand-orange mb-2">2010</span>
              <span className="text-sm text-zinc-500 uppercase tracking-wider">Year Founded</span>
            </div>
          </div>
        </div>
      </section>

      {/* Expertise Tags */}
      <section className="py-section px-10 max-w-container mx-auto w-full text-center">
        <h2 className="text-2xl font-medium mb-10 text-black">Our Technical Domains</h2>
        <div className="flex flex-wrap justify-center gap-4 max-w-4xl mx-auto">
          {['Enterprise Architecture', 'Red Hat JBoss', 'OpenShift', 'Cloud Migration', 'IT Strategy', 'Program Management', 'Agile Delivery', 'Microservices', 'API Management', 'DevOps'].map((tag) => (
            <span key={tag} className="px-6 py-3 rounded-full border border-zinc-200 text-zinc-600 text-sm hover:border-brand-orange hover:text-brand-orange transition-colors cursor-default bg-white">
              {tag}
            </span>
          ))}
        </div>
      </section>

      <ContactCTA />
    </main>
  );
}
