import ContactForm from '@/components/forms/ContactForm';
import { MapPin, Mail, Clock } from 'lucide-react';
import Divider from '@/components/ui/Divider';
import SectionLabel from '@/components/ui/SectionLabel';
import { FadeUpStagger, FadeUpItem } from '@/components/ui/MotionWrapper';

export const metadata = {
  title: "Contact Straveda LLC — Start Your Enterprise IT Project | Plano, TX",
  description: "Get in touch with Straveda LLC. Enterprise IT consulting, architecture, and technology strategy. Plano, TX 75024. Respond within 1 business day.",
  alternates: { canonical: 'https://straveda.com/contact' },
};

export default function ContactPage() {
  return (
    <main className="flex flex-col min-h-screen pt-16">
      {/* Hero */}
      <section className="min-h-[50vh] flex items-center justify-center px-10 py-24 bg-zinc-50">
        <FadeUpStagger className="max-w-container mx-auto w-full text-center">
          <FadeUpItem>
            <SectionLabel className="mx-auto">Get in Touch</SectionLabel>
          </FadeUpItem>
          <FadeUpItem>
            <h1 className="text-hero font-semibold mb-8 text-black tracking-tight">
              Let&apos;s build <span className="text-brand-orange">together.</span>
            </h1>
          </FadeUpItem>
          <FadeUpItem>
            <p className="text-lg text-zinc-600 max-w-2xl mx-auto">
              Ready to transform your enterprise IT? Reach out to our team of experts to discuss your next strategic initiative.
            </p>
          </FadeUpItem>
        </FadeUpStagger>
      </section>

      <Divider />

      {/* Contact Section */}
      <section className="py-section px-10 max-w-container mx-auto w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Form */}
          <div className="bg-white rounded-2xl p-8 md:p-10 border border-zinc-200 shadow-sm">
            <h2 className="text-2xl font-medium mb-8 text-black">Send us a message</h2>
            <ContactForm />
          </div>

          {/* Info */}
          <div className="flex flex-col gap-12 lg:py-10">
            <div>
              <h2 className="text-3xl font-medium mb-6 text-black">Contact Information</h2>
              <p className="text-zinc-600 leading-[1.65] mb-8">
                We aim to respond to all inquiries within one business day. For urgent matters, please indicate so in your message.
              </p>
            </div>

            <div className="flex flex-col gap-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-brand-orange/10 flex items-center justify-center shrink-0">
                  <MapPin className="text-brand-orange" size={24} />
                </div>
                <div>
                  <h3 className="text-lg font-medium mb-1 text-black">Headquarters</h3>
                  <p className="text-zinc-600">Plano, Texas 75024<br />United States</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-brand-orange/10 flex items-center justify-center shrink-0">
                  <Mail className="text-brand-orange" size={24} />
                </div>
                <div>
                  <h3 className="text-lg font-medium mb-1 text-black">Email Us</h3>
                  <a href="mailto:info@straveda.com" className="text-zinc-600 hover:text-brand-orange transition-colors">info@straveda.com</a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-brand-orange/10 flex items-center justify-center shrink-0">
                  <Clock className="text-brand-orange" size={24} />
                </div>
                <div>
                  <h3 className="text-lg font-medium mb-1 text-black">Business Hours</h3>
                  <p className="text-zinc-600">Monday - Friday<br />9:00 AM - 6:00 PM CST</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
