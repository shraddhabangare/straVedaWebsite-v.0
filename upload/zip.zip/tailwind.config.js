/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{js,jsx,ts,tsx}', './components/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          orange:  '#FF4800',
          'orange-hover': '#e63f00',
        },
        zinc: {
          50: '#FAFAFA',
          100: '#F4F4F5',
          200: '#E4E4E7',
          300: '#D4D4D8',
          400: '#A1A1A1',
          500: '#71717A',
          600: '#52525B',
          800: '#27272A',
          900: '#18181B',
        },
      },
      fontFamily: {
        geist: ['var(--font-geist)', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        'display':   ['clamp(64px, 10vw, 140px)', { lineHeight: '0.92', letterSpacing: '-0.03em' }],
        'hero':      ['clamp(48px, 7vw, 96px)',   { lineHeight: '0.95', letterSpacing: '-0.02em' }],
        'section':   ['clamp(32px, 4vw, 48px)',   { lineHeight: '1.1' }],
      },
      spacing: {
        'section': '96px',
        'section-sm': '64px',
      },
      maxWidth: {
        'container': '1280px',
      },
      borderColor: {
        DEFAULT: '#E4E4E7',
      },
      animation: {
        'fade-up':  'fadeUp 0.6s ease forwards',
        'pulse-glow': 'pulseGlow 2s ease-in-out infinite',
      },
      keyframes: {
        fadeUp: {
          from: { opacity: '0', transform: 'translateY(24px)' },
          to:   { opacity: '1', transform: 'translateY(0)' },
        },
        pulseGlow: {
          '0%, 100%': { boxShadow: '0 0 0 0 rgba(255, 72, 0, 0)' },
          '50%':      { boxShadow: '0 0 24px 6px rgba(255, 72, 0, 0.25)' },
        },
      },
    },
  },
  plugins: [],
};
