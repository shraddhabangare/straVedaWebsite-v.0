'use client';

import { useState } from 'react';

export default function ContactForm() {
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    // Simulate API call
    setTimeout(() => {
      setStatus('success');
    }, 1500);
  };

  if (status === 'success') {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center animate-fade-up">
        <div className="w-16 h-16 bg-green-500/10 text-green-600 rounded-full flex items-center justify-center mb-6">
          <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <h3 className="text-2xl font-medium mb-2 text-black">Message Sent</h3>
        <p className="text-zinc-600">Thank you for reaching out. We will get back to you shortly.</p>
        <button 
          onClick={() => setStatus('idle')}
          className="mt-8 text-brand-orange hover:text-brand-orange-hover transition-colors text-sm font-medium"
        >
          Send another message
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="flex flex-col gap-2">
          <label htmlFor="fullName" className="text-sm font-medium text-zinc-700">Full Name *</label>
          <input 
            type="text" 
            id="fullName" 
            required
            className="bg-zinc-50 border border-zinc-200 rounded-lg px-4 py-3 text-black focus:outline-none focus:border-brand-orange focus:ring-1 focus:ring-brand-orange transition-all"
            placeholder="John Doe"
          />
        </div>
        <div className="flex flex-col gap-2">
          <label htmlFor="company" className="text-sm font-medium text-zinc-700">Company *</label>
          <input 
            type="text" 
            id="company" 
            required
            className="bg-zinc-50 border border-zinc-200 rounded-lg px-4 py-3 text-black focus:outline-none focus:border-brand-orange focus:ring-1 focus:ring-brand-orange transition-all"
            placeholder="Acme Corp"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="flex flex-col gap-2">
          <label htmlFor="email" className="text-sm font-medium text-zinc-700">Work Email *</label>
          <input 
            type="email" 
            id="email" 
            required
            className="bg-zinc-50 border border-zinc-200 rounded-lg px-4 py-3 text-black focus:outline-none focus:border-brand-orange focus:ring-1 focus:ring-brand-orange transition-all"
            placeholder="john@acme.com"
          />
        </div>
        <div className="flex flex-col gap-2">
          <label htmlFor="phone" className="text-sm font-medium text-zinc-700">Phone</label>
          <input 
            type="tel" 
            id="phone" 
            className="bg-zinc-50 border border-zinc-200 rounded-lg px-4 py-3 text-black focus:outline-none focus:border-brand-orange focus:ring-1 focus:ring-brand-orange transition-all"
            placeholder="+1 (555) 000-0000"
          />
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <label htmlFor="service" className="text-sm font-medium text-zinc-700">Service Interest</label>
        <select 
          id="service" 
          className="bg-zinc-50 border border-zinc-200 rounded-lg px-4 py-3 text-black focus:outline-none focus:border-brand-orange focus:ring-1 focus:ring-brand-orange transition-all appearance-none"
        >
          <option value="">Select a service...</option>
          <option value="architecture">Enterprise Architecture</option>
          <option value="strategy">Technology Strategy</option>
          <option value="consulting">Management Consulting</option>
          <option value="software">Software Solutions</option>
          <option value="other">Other</option>
        </select>
      </div>

      <div className="flex flex-col gap-2">
        <label htmlFor="message" className="text-sm font-medium text-zinc-700">Message *</label>
        <textarea 
          id="message" 
          required
          rows={5}
          className="bg-zinc-50 border border-zinc-200 rounded-lg px-4 py-3 text-black focus:outline-none focus:border-brand-orange focus:ring-1 focus:ring-brand-orange transition-all resize-none"
          placeholder="Tell us about your project or inquiry..."
        />
      </div>

      <button 
        type="submit" 
        disabled={status === 'submitting'}
        className="bg-brand-orange text-white font-medium px-8 py-4 rounded-lg hover:bg-brand-orange-hover transition-all duration-250 disabled:opacity-70 disabled:cursor-not-allowed mt-2"
      >
        {status === 'submitting' ? 'Sending...' : 'Send Message'}
      </button>
    </form>
  );
}
