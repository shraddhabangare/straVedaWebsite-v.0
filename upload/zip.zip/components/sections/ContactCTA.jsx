'use client';

import Button from '../ui/Button';
import { motion } from 'motion/react';
import { fadeUpVariants, staggerContainer } from '@/lib/animations';

export default function ContactCTA() {
  return (
    <section className="py-section px-10 w-full bg-zinc-50 border-t border-zinc-200 text-center overflow-hidden">
      <motion.div 
        className="max-w-3xl mx-auto flex flex-col items-center"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
        variants={staggerContainer}
      >
        <motion.h2 variants={fadeUpVariants} className="text-section font-medium mb-6 text-black tracking-tight">Ready to modernize your IT?</motion.h2>
        <motion.p variants={fadeUpVariants} className="text-lg text-zinc-600 mb-10">
          Let&apos;s discuss how Straveda can help align your technology strategy with your business goals.
        </motion.p>
        <motion.div variants={fadeUpVariants}>
          <Button href="/contact" variant="primary" className="animate-pulse-glow">
            Contact Our Experts
          </Button>
        </motion.div>
      </motion.div>
    </section>
  );
}
