'use client';

import Button from '../ui/Button';
import { Star } from 'lucide-react';
import { motion } from 'motion/react';
import { fadeUpVariants, staggerContainer } from '@/lib/animations';
import Image from 'next/image';

export default function Hero() {
  const headingText = "Less complexity, more agility.";
  const words = headingText.split(" ");

  const wordVariants = {
    hidden: { opacity: 0, y: 40 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] }
    }
  };

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-10 pt-32 pb-24 overflow-hidden bg-zinc-50">
      <motion.div 
        className="max-w-container mx-auto w-full flex flex-col items-center text-center z-10"
        variants={staggerContainer}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={fadeUpVariants} className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-white shadow-[0_0_0_1px_#E4E4E7] mb-10">
          <div className="flex text-brand-orange">
            <Star size={14} fill="currentColor" />
            <Star size={14} fill="currentColor" />
            <Star size={14} fill="currentColor" />
            <Star size={14} fill="currentColor" />
            <Star size={14} fill="currentColor" />
          </div>
          <span className="text-xs font-medium text-zinc-600 uppercase tracking-widest">5.0 Google Rating</span>
        </motion.div>
        
        <h1 className="text-hero font-semibold mb-10 max-w-5xl text-black tracking-tight flex flex-wrap justify-center gap-x-4 gap-y-2">
          {words.map((word, i) => (
            <span key={i} className="overflow-hidden inline-block pb-2">
              <motion.span 
                className={`inline-block ${word.includes('agility') ? 'text-brand-orange' : ''}`}
                variants={wordVariants}
              >
                {word}
              </motion.span>
            </span>
          ))}
        </h1>
        
        <motion.p variants={fadeUpVariants} className="text-xl text-zinc-600 max-w-2xl mb-14 leading-[1.65]">
          Enterprise architecture, technology strategy, and management consulting for forward-thinking organizations. Based in Plano, Texas.
        </motion.p>
        
        <motion.div variants={fadeUpVariants} className="flex flex-col sm:flex-row items-center gap-6 mb-20">
          <Button href="/contact" variant="primary" className="w-full sm:w-auto">
            Start Your Project
          </Button>
          <Button href="/services" variant="secondary" className="w-full sm:w-auto">
            Explore Services
          </Button>
        </motion.div>

        {/* Phase 6: Image Reveal Animation */}
        <motion.div 
          className="w-full max-w-5xl mx-auto h-[50vh] md:h-[60vh] rounded-3xl overflow-hidden relative shadow-2xl"
          initial={{ clipPath: 'inset(20% 10% 20% 10% round 24px)' }}
          animate={{ clipPath: 'inset(0% 0% 0% 0% round 24px)' }}
          transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1], delay: 0.4 }}
        >
          <motion.div
            className="w-full h-full relative"
            initial={{ scale: 1.2 }}
            animate={{ scale: 1 }}
            transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1], delay: 0.4 }}
          >
            <Image 
              src="https://picsum.photos/seed/straveda/1920/1080" 
              alt="Enterprise IT Consulting" 
              fill 
              className="object-cover" 
              referrerPolicy="no-referrer"
              priority
            />
          </motion.div>
        </motion.div>
      </motion.div>
      
      {/* Subtle background glow */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 2, ease: "easeOut" }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-brand-orange/5 rounded-full blur-[120px] pointer-events-none" 
      />
    </section>
  );
}
