'use client';

import { motion } from 'motion/react';
import { fadeUpVariants, staggerContainer } from '@/lib/animations';

export default function Newsletter() {
  return (
    <section className="w-full bg-zinc-50 border-t border-zinc-200 overflow-hidden">
      <motion.div 
        className="max-w-container mx-auto px-10 py-24 text-center"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
        variants={staggerContainer}
      >
        <motion.h2 variants={fadeUpVariants} className="text-3xl font-medium mb-4 text-black tracking-tight">Stay Ahead of the Curve</motion.h2>
        <motion.p variants={fadeUpVariants} className="text-zinc-600 mb-8 max-w-xl mx-auto">
          Subscribe to our newsletter for the latest insights on enterprise architecture, technology strategy, and industry trends.
        </motion.p>
        <motion.form variants={fadeUpVariants} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto" action="#">
          <input 
            type="email" 
            placeholder="Enter your work email" 
            className="flex-1 bg-white border border-zinc-300 rounded-lg px-4 py-3 text-black focus:outline-none focus:border-brand-orange transition-colors"
            required
          />
          <button type="submit" className="bg-brand-orange text-white font-medium px-6 py-3 rounded-lg hover:bg-brand-orange-hover transition-colors whitespace-nowrap">
            Subscribe
          </button>
        </motion.form>
      </motion.div>
    </section>
  );
}
