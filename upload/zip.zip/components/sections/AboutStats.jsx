'use client';

import SectionLabel from '../ui/SectionLabel';
import { motion } from 'motion/react';
import { fadeUpVariants, staggerContainer } from '@/lib/animations';

export default function AboutStats() {
  return (
    <section className="py-section px-10 max-w-container mx-auto w-full overflow-hidden">
      <motion.div 
        className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
        variants={staggerContainer}
      >
        <motion.div variants={fadeUpVariants}>
          <h2 className="text-display font-semibold text-brand-orange tracking-tight">
            14+
          </h2>
          <p className="text-section font-medium mt-4 text-black tracking-tight">
            Years of enterprise excellence.
          </p>
        </motion.div>
        
        <motion.div variants={fadeUpVariants} className="flex flex-col gap-8">
          <SectionLabel>Our Mission</SectionLabel>
          <p className="text-lg md:text-xl text-zinc-700 leading-[1.65]">
            Provide Exceptional Value. Deliver Cost-Effective Solutions. Guarantee Customer Satisfaction. Since 2010, we have been the trusted partner for organizations navigating complex digital transformations.
          </p>
          
          <div className="grid grid-cols-2 gap-6 pt-6 border-t border-zinc-200">
            <div>
              <div className="text-3xl font-semibold mb-2 text-black">7</div>
              <div className="text-sm text-zinc-600">Expert Consultants</div>
            </div>
            <div>
              <div className="text-3xl font-semibold mb-2 text-black">100%</div>
              <div className="text-sm text-zinc-600">Client Satisfaction</div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
}
