'use client';

import { Quote, Star } from 'lucide-react';
import Card from '../ui/Card';
import SectionLabel from '../ui/SectionLabel';
import { motion } from 'motion/react';
import { fadeUpVariants, staggerContainer } from '@/lib/animations';

export default function Testimonials() {
  const testimonials = [
    {
      quote: "Straveda transformed our legacy systems into a modern, agile architecture. Their strategic insight was invaluable to our digital transformation.",
      author: "CTO, Financial Services",
    },
    {
      quote: "The management consulting team delivered our complex enterprise program on time and under budget. Exceptional professionalism and expertise.",
      author: "VP Engineering, Healthcare",
    },
    {
      quote: "Their deep knowledge of Red Hat middleware helped us significantly lower our TCO while improving system reliability and performance.",
      author: "Director of IT, Manufacturing",
    }
  ];

  return (
    <section className="py-section px-10 max-w-container mx-auto w-full overflow-hidden">
      <motion.div 
        className="text-center mb-16"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
        variants={staggerContainer}
      >
        <motion.div variants={fadeUpVariants}>
          <SectionLabel className="mx-auto">Client Success</SectionLabel>
          <h2 className="text-section font-medium text-black tracking-tight">Trusted by Enterprise Leaders</h2>
        </motion.div>
      </motion.div>

      <motion.div 
        className="grid grid-cols-1 md:grid-cols-3 gap-8"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-50px" }}
        variants={staggerContainer}
      >
        {testimonials.map((testimonial, i) => (
          <motion.div key={i} variants={fadeUpVariants} className="h-full">
            <Card className="flex flex-col h-full">
              <Quote size={32} className="text-brand-orange mb-6 opacity-20" />
              <p className="text-[15px] leading-[1.6] text-zinc-700 flex-grow mb-6">
                &quot;{testimonial.quote}&quot;
              </p>
              <div>
                <div className="flex text-brand-orange mb-2">
                  <Star size={14} fill="currentColor" />
                  <Star size={14} fill="currentColor" />
                  <Star size={14} fill="currentColor" />
                  <Star size={14} fill="currentColor" />
                  <Star size={14} fill="currentColor" />
                </div>
                <p className="text-sm font-medium text-black">{testimonial.author}</p>
              </div>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    </section>
  );
}
