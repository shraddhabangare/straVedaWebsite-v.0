'use client';

import Link from 'next/link';
import { ArrowRight, Building2, Lightbulb, LineChart, Server } from 'lucide-react';
import Card from '../ui/Card';
import SectionLabel from '../ui/SectionLabel';
import { motion } from 'motion/react';
import { fadeUpVariants, staggerContainer } from '@/lib/animations';

export default function ServicesGrid() {
  const services = [
    {
      title: "Enterprise Architecture",
      desc: "Modernize application portfolios with adaptive, open-standards architecture.",
      icon: <Building2 size={24} className="text-brand-orange" />
    },
    {
      title: "Technology Strategy",
      desc: "Align IT investments with business goals for faster time to market.",
      icon: <Lightbulb size={24} className="text-brand-orange" />
    },
    {
      title: "Management Consulting",
      desc: "Expert Product, Program & Project management for enterprise delivery.",
      icon: <LineChart size={24} className="text-brand-orange" />
    },
    {
      title: "Software Solutions",
      desc: "Red Hat Enterprise Middleware and virtualization to lower TCO.",
      icon: <Server size={24} className="text-brand-orange" />
    }
  ];

  return (
    <section className="py-section px-10 max-w-container mx-auto w-full">
      <motion.div 
        className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
        variants={staggerContainer}
      >
        <motion.div variants={fadeUpVariants}>
          <SectionLabel>Our Expertise</SectionLabel>
          <h2 className="text-section font-medium text-black tracking-tight">Enterprise IT Solutions</h2>
        </motion.div>
        <motion.div variants={fadeUpVariants}>
          <Link href="/services" className="text-zinc-600 text-sm font-normal hover:text-brand-orange transition-colors duration-200 inline-flex items-center gap-1.5">
            View all services <ArrowRight size={16} />
          </Link>
        </motion.div>
      </motion.div>

      <motion.div 
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-50px" }}
        variants={staggerContainer}
      >
        {services.map((service, i) => (
          <motion.div key={i} variants={fadeUpVariants} className="h-full">
            <Card className="flex flex-col h-full">
              <div className="w-12 h-12 rounded-lg bg-brand-orange/10 flex items-center justify-center mb-6">
                {service.icon}
              </div>
              <h3 className="text-[22px] font-medium leading-[1.3] mb-3 text-black">{service.title}</h3>
              <p className="text-zinc-600 text-[15px] leading-[1.6] flex-grow">{service.desc}</p>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    </section>
  );
}
