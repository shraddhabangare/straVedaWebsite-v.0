export default function OpenGraph() {
  return null; // Handled via Next.js metadata API
}
