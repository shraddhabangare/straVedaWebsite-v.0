export default function Card({ children, className = '', ...props }) {
  return (
    <div 
      className={`bg-white rounded-2xl p-10 border border-zinc-200 transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] hover:scale-[1.05] hover:shadow-[0_32px_64px_rgba(0,0,0,0.06)] group ${className}`}
      {...props}
    >
      {children}
    </div>
  );
}
