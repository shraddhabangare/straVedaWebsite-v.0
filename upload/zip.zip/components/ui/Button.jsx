import Link from 'next/link';

export default function Button({ children, variant = 'primary', href, className = '', ...props }) {
  const baseClasses = "transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] rounded-full inline-flex items-center justify-center font-medium text-[15px] px-8 py-4";
  
  const variants = {
    primary: "bg-brand-orange text-white hover:bg-brand-orange-hover hover:scale-[1.04] shadow-[0_0_0_1px_#FF4800] hover:shadow-[0_8px_24px_rgba(255,72,0,0.3)]",
    secondary: "bg-white text-black shadow-[0_0_0_1px_#E4E4E7] hover:shadow-[0_0_0_1px_#000000] hover:scale-[1.04]",
    ghost: "text-zinc-600 hover:text-black gap-1.5"
  };

  const classes = `${baseClasses} ${variants[variant]} ${className}`;

  if (href) {
    return (
      <Link href={href} className={classes} {...props}>
        {children}
      </Link>
    );
  }

  return (
    <button className={classes} {...props}>
      {children}
    </button>
  );
}
