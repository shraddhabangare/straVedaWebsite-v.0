'use client';

import { motion } from 'motion/react';
import { fadeUpVariants, staggerContainer } from '@/lib/animations';

export function FadeUpStagger({ children, className = '' }) {
  return (
    <motion.div
      className={className}
      variants={staggerContainer}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-50px" }}
    >
      {children}
    </motion.div>
  );
}

export function FadeUpItem({ children, className = '' }) {
  return (
    <motion.div variants={fadeUpVariants} className={className}>
      {children}
    </motion.div>
  );
}
