export default function Divider({ className = '' }) {
  return (
    <hr className={`border-t border-zinc-200 ${className}`} />
  );
}
