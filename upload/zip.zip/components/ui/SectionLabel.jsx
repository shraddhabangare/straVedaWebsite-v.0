export default function SectionLabel({ children, className = '' }) {
  return (
    <span className={`text-xs font-medium uppercase tracking-[0.14em] text-zinc-500 block mb-4 ${className}`}>
      {children}
    </span>
  );
}
