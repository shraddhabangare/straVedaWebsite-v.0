import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-zinc-50 border-t-2 border-brand-orange">
      <div className="max-w-container mx-auto px-10 pt-16 pb-10">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8">
          {/* Col 1 */}
          <div className="lg:col-span-1">
            <Link href="/" className="text-black font-medium text-lg flex items-center gap-1 mb-4" aria-label="Straveda Home">
              <span>Straveda</span>
              <span className="text-brand-orange">.</span>
            </Link>
            <p className="text-zinc-600 text-[14px] max-w-[200px] mb-6">
              Exceptional value. Cost-effective solutions.
            </p>
            <a href="https://www.linkedin.com/company/straveda-llc" target="_blank" rel="noopener noreferrer" className="text-zinc-400 hover:text-brand-orange transition-colors" aria-label="LinkedIn">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                <rect x="2" y="9" width="4" height="12"></rect>
                <circle cx="4" cy="4" r="2"></circle>
              </svg>
            </a>
          </div>

          {/* Col 2 */}
          <div>
            <h3 className="uppercase text-[11px] tracking-[0.14em] text-brand-orange font-medium mb-4">Services</h3>
            <ul className="flex flex-col gap-3">
              <li><Link href="/services#architecture" className="text-zinc-600 text-sm hover:text-black transition-colors">Enterprise Architecture</Link></li>
              <li><Link href="/services#strategy" className="text-zinc-600 text-sm hover:text-black transition-colors">Technology Strategy</Link></li>
              <li><Link href="/services#consulting" className="text-zinc-600 text-sm hover:text-black transition-colors">Management Consulting</Link></li>
              <li><Link href="/services#software" className="text-zinc-600 text-sm hover:text-black transition-colors">Software Solutions</Link></li>
            </ul>
          </div>

          {/* Col 3 */}
          <div>
            <h3 className="uppercase text-[11px] tracking-[0.14em] text-brand-orange font-medium mb-4">Company</h3>
            <ul className="flex flex-col gap-3">
              <li><Link href="/about" className="text-zinc-600 text-sm hover:text-black transition-colors">About Us</Link></li>
              <li><Link href="/insights" className="text-zinc-600 text-sm hover:text-black transition-colors">Insights</Link></li>
              <li><Link href="/contact" className="text-zinc-600 text-sm hover:text-black transition-colors">Contact</Link></li>
            </ul>
          </div>

          {/* Col 4 */}
          <div>
            <h3 className="uppercase text-[11px] tracking-[0.14em] text-brand-orange font-medium mb-4">Contact</h3>
            <ul className="flex flex-col gap-3">
              <li className="text-zinc-600 text-sm">Plano, Texas 75024</li>
              <li><a href="mailto:info@straveda.com" className="text-zinc-600 text-sm hover:text-black transition-colors">info@straveda.com</a></li>
            </ul>
          </div>

          {/* Col 5 */}
          <div>
            <h3 className="uppercase text-[11px] tracking-[0.14em] text-brand-orange font-medium mb-4">Legal</h3>
            <ul className="flex flex-col gap-3">
              <li><Link href="#" className="text-zinc-600 text-sm hover:text-black transition-colors">Privacy Policy</Link></li>
              <li><Link href="#" className="text-zinc-600 text-sm hover:text-black transition-colors">Terms of Service</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-zinc-200 pt-6 mt-10 flex flex-col md:flex-row justify-between items-center gap-4 text-zinc-500 text-xs">
          <p>© 2024 Straveda LLC. All rights reserved.</p>
          <Link href="#" className="hover:text-zinc-800 transition-colors">Privacy Policy</Link>
        </div>
      </div>
    </footer>
  );
}
