'use client';

import Link from 'next/link';
import Button from '../ui/Button';
import { motion } from 'motion/react';

export default function Navbar() {
  return (
    <motion.header 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      className="fixed top-0 left-0 right-0 z-50 h-16 bg-white/95 backdrop-blur-md border-b border-zinc-200"
    >
      <div className="max-w-container mx-auto px-10 flex items-center justify-between h-full">
        <Link href="/" className="text-black font-medium text-lg flex items-center gap-1" aria-label="Straveda Home">
          <span>Straveda</span>
          <span className="text-brand-orange">.</span>
        </Link>
        
        <nav aria-label="Main navigation" className="hidden md:flex items-center gap-8">
          <Link href="/services" className="text-zinc-500 text-[15px] font-medium hover:text-black transition-colors duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]">
            Services
          </Link>
          <Link href="/about" className="text-zinc-500 text-[15px] font-medium hover:text-black transition-colors duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]">
            About
          </Link>
          <Link href="/insights" className="text-zinc-500 text-[15px] font-medium hover:text-black transition-colors duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]">
            Insights
          </Link>
        </nav>

        <Button href="/contact" variant="primary">
          Contact Us
        </Button>
      </div>
    </motion.header>
  );
}
